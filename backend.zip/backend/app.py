from flask import Flask, request, jsonify
from flask_cors import CORS
import json
import os
import uuid

app = Flask(__name__)
# Mengizinkan CORS untuk komunikasi antara frontend (localhost:3000) dan backend (localhost:5000)
CORS(app) 

# Nama file JSON yang akan digunakan sebagai database
DATA_FILE = 'students.json'

def load_students():
    """Memuat data mahasiswa dari file JSON."""
    if not os.path.exists(DATA_FILE):
        # Jika file tidak ada, buat file kosong dengan list kosong
        with open(DATA_FILE, 'w') as f:
            json.dump([], f)
    with open(DATA_FILE, 'r') as f:
        return json.load(f)

def save_students(students):
    """Menyimpan data mahasiswa ke file JSON."""
    with open(DATA_FILE, 'w') as f:
        # Menggunakan indent=4 agar file JSON mudah dibaca
        json.dump(students, f, indent=4)

@app.route('/students', methods=['GET'])
def get_students():
    """Endpoint untuk mendapatkan semua data mahasiswa."""
    students = load_students()
    return jsonify(students)

@app.route('/students', methods=['POST'])
def add_student():
    """Endpoint untuk menambahkan mahasiswa baru."""
    new_student = request.json # Mendapatkan data JSON dari request body
    students = load_students()
    
    # Generate ID unik untuk mahasiswa baru
    new_student['id'] = str(uuid.uuid4()) 
    
    students.append(new_student)
    save_students(students)
    return jsonify(new_student), 201 # Mengembalikan mahasiswa yang baru ditambahkan dengan status 201 Created

@app.route('/students/<string:student_id>', methods=['DELETE'])
def delete_student(student_id):
    """Endpoint untuk menghapus mahasiswa berdasarkan ID."""
    students = load_students()
    initial_len = len(students)
    
    # Filter mahasiswa, hapus yang memiliki ID yang cocok
    students = [s for s in students if s['id'] != student_id]
    
    if len(students) == initial_len:
        # Jika panjang list tidak berubah, berarti student_id tidak ditemukan
        return jsonify({"message": "Student not found"}), 404
    
    save_students(students)
    return jsonify({"message": "Student deleted successfully"}), 200 # Mengembalikan pesan sukses dengan status 200 OK

if __name__ == '__main__':
    # Jalankan aplikasi Flask dalam mode debug
    # Mode debug akan otomatis me-reload server jika ada perubahan kode
    app.run(debug=True)